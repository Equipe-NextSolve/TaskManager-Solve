'use client'
import { useState } from 'react'
import Link from "next/link"
import { menuItems } from "./Icons"
import { BurgerButton } from './BurgerBtn';
import { useEffect } from 'react';
import { auth } from '@/lib/firebaseConfig';
import { onAuthStateChanged } from 'firebase/auth';

export default function SideMenuItems() {
    const [isOpen, setIsOpen] = useState(false)
    const [user, setUser] = useState(null)
    
    useEffect(()=>{
        const unsub = onAuthStateChanged(auth,(firebaseUser) => {
            setUser(firebaseUser)
            
        })
        return () => unsub()
    }, [])

    return (
        <div
            className={`overflow-hidden h-full fixed top-0 left-0 bg-linear-to-br from-bg-pure via-[#050505] to-bg-pure flex flex-col gap-3 py-10 transition-all duration-300 ease-in-out ${isOpen ? 'w-64 items-start px-4' : 'w-20 items-center'} shadow-xl z-50`}
            onMouseEnter={() => setIsOpen(true)}
            onMouseLeave={() => setIsOpen(false)}
        >
            
            <div className="mb-6 px-2">
                <div className={`transition-all duration-300 ${isOpen ? 'opacity-100' : 'opacity-0'}`}>
                    {user.photoURL?<Image
                        src={user.photoURL}
                        
                        fill
                        className="object-cover"
                        sizes="32px"
                    />:'Sem foto'}
                </div>
            </div>

            <div style={{
                width: isOpen? '90%' : '70%',
                height: '1px',
                borderRadius:'5px',
                background: 'rgba(73, 73, 73, 0.41)',
                margin: '4px auto',
                
            }} 

            />
            {menuItems.map ((item)=>(
                <Link
                        key={item.label}
                        href={item.href}
                        className={`h-12 flex items-center gap-4 text-[#6d6d6d] hover:text-white hover:bg-[#1a1a1a] rounded-lg p-3 transition-all duration-200 ease-in-out ${isOpen ? 'w-full justify-start' : 'w-12 justify-center mx-auto'}`}
                    >   
                        <item.icon
                            className="text-2xl min-w-6 transition-transform duration-200 hover:scale-110"
                        />
                        <span className={`text-sm font-medium whitespace-nowrap transition-opacity duration-300 ${isOpen ? 'opacity-100 block' : 'opacity-0 hidden'}`}>
                            {item.label}
                        </span>
                    </Link>
        
            ))}
        </div>
        
    )
}
